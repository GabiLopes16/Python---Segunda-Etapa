import os
import sqlite3
from functools import wraps

import requests

from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    session,
    flash,
    jsonify
)

from werkzeug.security import (
    generate_password_hash,
    check_password_hash
)

app = Flask(__name__)

app.config["SECRET_KEY"] = os.environ.get(
    "SECRET_KEY",
    "chave-secreta-desenvolvimento"
)

DATABASE = "banco.db"

STATUS_VALIDOS = [
    "Pendente",
    "Em andamento",
    "Concluída"
]

def conectar_banco():

    conexao = sqlite3.connect(DATABASE)

    conexao.row_factory = sqlite3.Row

    return conexao


def inicializar_banco():

    conexao = conectar_banco()

    cursor = conexao.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            senha TEXT NOT NULL
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS tarefas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            titulo TEXT NOT NULL,
            descricao TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'Pendente',
            usuario_id INTEGER NOT NULL,
            FOREIGN KEY (usuario_id)
                REFERENCES usuarios(id)
        )
    """)

    conexao.commit()

    conexao.close()

def usuario_logado():

    return session.get("usuario_id")


def login_obrigatorio(funcao):

    @wraps(funcao)
    def wrapper(*args, **kwargs):

        if not usuario_logado():

            flash(
                "Faça login para acessar esta página.",
                "warning"
            )

            return redirect(
                url_for("login")
            )

        return funcao(*args, **kwargs)

    return wrapper

@app.route("/")
def index():

    if usuario_logado():

        return redirect(
            url_for("dashboard")
        )

    return redirect(
        url_for("login")
    )

@app.route("/registro", methods=["GET", "POST"])
def registro():

    if request.method == "POST":

        nome = request.form.get(
            "nome",
            ""
        ).strip()

        email = request.form.get(
            "email",
            ""
        ).strip().lower()

        senha = request.form.get(
            "senha",
            ""
        )

        if not nome or not email or not senha:

            flash(
                "Preencha todos os campos.",
                "danger"
            )

            return render_template(
                "registro.html"
            )

        if len(nome) < 2:

            flash(
                "Digite um nome válido.",
                "danger"
            )

            return render_template(
                "registro.html"
            )

        if len(senha) < 6:

            flash(
                "A senha deve possuir pelo menos 6 caracteres.",
                "danger"
            )

            return render_template(
                "registro.html"
            )

        senha_hash = generate_password_hash(
            senha
        )

        conexao = conectar_banco()

        try:

            conexao.execute(
                """
                INSERT INTO usuarios
                (nome, email, senha)
                VALUES (?, ?, ?)
                """,
                (
                    nome,
                    email,
                    senha_hash
                )
            )

            conexao.commit()

        except sqlite3.IntegrityError:

            conexao.close()

            flash(
                "Este e-mail já está cadastrado.",
                "danger"
            )

            return render_template(
                "registro.html"
            )

        conexao.close()

        flash(
            "Cadastro realizado com sucesso!",
            "success"
        )

        return redirect(
            url_for("login")
        )

    return render_template(
        "registro.html"
    )

@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        email = request.form.get(
            "email",
            ""
        ).strip().lower()

        senha = request.form.get(
            "senha",
            ""
        )

        conexao = conectar_banco()

        usuario = conexao.execute(
            """
            SELECT *
            FROM usuarios
            WHERE email = ?
            """,
            (email,)
        ).fetchone()

        conexao.close()

        if usuario and check_password_hash(
            usuario["senha"],
            senha
        ):

            session.clear()

            session["usuario_id"] = usuario["id"]

            session["usuario_nome"] = usuario["nome"]

            return redirect(
                url_for("dashboard")
            )

        flash(
            "E-mail ou senha incorretos.",
            "danger"
        )

    return render_template(
        "login.html"
    )

@app.route("/logout")
def logout():

    session.clear()

    flash(
        "Você saiu da sua conta.",
        "info"
    )

    return redirect(
        url_for("login")
    )

@app.route("/dashboard")
@login_obrigatorio
def dashboard():

    conexao = conectar_banco()

    tarefas = conexao.execute(
        """
        SELECT *
        FROM tarefas
        WHERE usuario_id = ?
        ORDER BY id DESC
        """,
        (usuario_logado(),)
    ).fetchall()

    conexao.close()

    return render_template(
        "dashboard.html",
        tarefas=tarefas
    )

@app.route(
    "/nova_tarefa",
    methods=["GET", "POST"]
)
@login_obrigatorio
def nova_tarefa():

    if request.method == "POST":

        titulo = request.form.get(
            "titulo",
            ""
        ).strip()

        descricao = request.form.get(
            "descricao",
            ""
        ).strip()

        status = request.form.get(
            "status",
            "Pendente"
        )

        if not titulo or not descricao:

            flash(
                "Título e descrição são obrigatórios.",
                "danger"
            )

            return render_template(
                "nova_tarefa.html",
                status_validos=STATUS_VALIDOS
            )

        if status not in STATUS_VALIDOS:

            flash(
                "Status inválido.",
                "danger"
            )

            return render_template(
                "nova_tarefa.html",
                status_validos=STATUS_VALIDOS
            )

        conexao = conectar_banco()

        conexao.execute(
            """
            INSERT INTO tarefas
            (titulo, descricao, status, usuario_id)
            VALUES (?, ?, ?, ?)
            """,
            (
                titulo,
                descricao,
                status,
                usuario_logado()
            )
        )

        conexao.commit()

        conexao.close()

        flash(
            "Tarefa criada com sucesso!",
            "success"
        )

        return redirect(
            url_for("dashboard")
        )

    return render_template(
        "nova_tarefa.html",
        status_validos=STATUS_VALIDOS
    )

@app.route(
    "/editar/<int:id>",
    methods=["GET", "POST"]
)
@login_obrigatorio
def editar_tarefa(id):

    conexao = conectar_banco()

    tarefa = conexao.execute(
        """
        SELECT *
        FROM tarefas
        WHERE id = ?
        AND usuario_id = ?
        """,
        (
            id,
            usuario_logado()
        )
    ).fetchone()

    if not tarefa:

        conexao.close()

        flash(
            "Tarefa não encontrada.",
            "danger"
        )

        return redirect(
            url_for("dashboard")
        )

    if request.method == "POST":

        titulo = request.form.get(
            "titulo",
            ""
        ).strip()

        descricao = request.form.get(
            "descricao",
            ""
        ).strip()

        status = request.form.get(
            "status",
            ""
        )

        if not titulo or not descricao:

            conexao.close()

            flash(
                "Título e descrição são obrigatórios.",
                "danger"
            )

            return render_template(
                "editar_tarefa.html",
                tarefa=tarefa,
                status_validos=STATUS_VALIDOS
            )

        if status not in STATUS_VALIDOS:

            conexao.close()

            flash(
                "Status inválido.",
                "danger"
            )

            return render_template(
                "editar_tarefa.html",
                tarefa=tarefa,
                status_validos=STATUS_VALIDOS
            )

        conexao.execute(
            """
            UPDATE tarefas
            SET titulo = ?,
                descricao = ?,
                status = ?
            WHERE id = ?
            AND usuario_id = ?
            """,
            (
                titulo,
                descricao,
                status,
                id,
                usuario_logado()
            )
        )

        conexao.commit()

        conexao.close()

        flash(
            "Tarefa atualizada com sucesso!",
            "success"
        )

        return redirect(
            url_for("dashboard")
        )

    conexao.close()

    return render_template(
        "editar_tarefa.html",
        tarefa=tarefa,
        status_validos=STATUS_VALIDOS
    )

@app.route(
    "/excluir/<int:id>",
    methods=["POST"]
)
@login_obrigatorio
def excluir_tarefa(id):

    conexao = conectar_banco()

    conexao.execute(
        """
        DELETE FROM tarefas
        WHERE id = ?
        AND usuario_id = ?
        """,
        (
            id,
            usuario_logado()
        )
    )

    conexao.commit()

    conexao.close()

    flash(
        "Tarefa excluída com sucesso.",
        "success"
    )

    return redirect(
        url_for("dashboard")
    )

@app.route("/api/tarefas/filtro")
@login_obrigatorio
def filtrar_tarefas():

    status = request.args.get(
        "status",
        "Todas"
    )

    conexao = conectar_banco()

    if status == "Todas":

        tarefas = conexao.execute(
            """
            SELECT
                id,
                titulo,
                descricao,
                status
            FROM tarefas
            WHERE usuario_id = ?
            ORDER BY id DESC
            """,
            (usuario_logado(),)
        ).fetchall()

    elif status in STATUS_VALIDOS:

        tarefas = conexao.execute(
            """
            SELECT
                id,
                titulo,
                descricao,
                status
            FROM tarefas
            WHERE usuario_id = ?
            AND status = ?
            ORDER BY id DESC
            """,
            (
                usuario_logado(),
                status
            )
        ).fetchall()

    else:

        conexao.close()

        return jsonify({
            "erro": "Status inválido."
        }), 400

    conexao.close()

    return jsonify([
        dict(tarefa)
        for tarefa in tarefas
    ])

@app.route(
    "/api/tarefas",
    methods=["GET"]
)
@login_obrigatorio
def api_listar_tarefas():

    conexao = conectar_banco()

    tarefas = conexao.execute(
        """
        SELECT
            id,
            titulo,
            descricao,
            status
        FROM tarefas
        WHERE usuario_id = ?
        ORDER BY id DESC
        """,
        (usuario_logado(),)
    ).fetchall()

    conexao.close()

    return jsonify([
        dict(tarefa)
        for tarefa in tarefas
    ])

@app.route("/api/frase")
@login_obrigatorio
def frase_motivacional():

    try:

        resposta = requests.get(
            "https://api.adviceslip.com/advice",
            timeout=5
        )

        resposta.raise_for_status()

        dados = resposta.json()

        return jsonify({
            "frase": dados["slip"]["advice"]
        })

    except requests.RequestException:

        return jsonify({
            "frase":
                "Continue avançando, um passo de cada vez!"
        })

@app.route("/api/progresso")
@login_obrigatorio
def progresso():

    conexao = conectar_banco()

    dados = conexao.execute(
        """
        SELECT
            status,
            COUNT(*) AS quantidade
        FROM tarefas
        WHERE usuario_id = ?
        GROUP BY status
        """,
        (usuario_logado(),)
    ).fetchall()

    conexao.close()

    resultado = {
        "Pendente": 0,
        "Em andamento": 0,
        "Concluída": 0
    }

    for item in dados:

        resultado[
            item["status"]
        ] = item["quantidade"]

    return jsonify(resultado)

@app.route("/progresso")
@login_obrigatorio
def pagina_progresso():

    return render_template(
        "progresso.html"
    )

if __name__ == "__main__":

    inicializar_banco()

    app.run(
        debug=True
    )